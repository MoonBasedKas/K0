// foo.kt
fun foo(x : Int, y : String) : Int {
   return x
   }
fun main() {
   var z : Int
   z = foo(5, ("funf").toString())
}